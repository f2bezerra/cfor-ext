//Tratamentos pós-carregamento
$(document).ready(function() {
	$('fieldset').removeClass().css("border", 0);
});

 
