﻿- Correção do resolvedor de expressão do interpretador de textos padrões;
- Correção do interpretador de textos padrões;
- Correção da consulta de serviço;